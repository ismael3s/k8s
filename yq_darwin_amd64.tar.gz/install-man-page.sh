#!/bin/sh

cp yq.1 /usr/local/share/man/man1/.